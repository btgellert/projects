﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using System.Net;
using static Idojaro.WeatherInfo;

namespace Idojaro
{
    delegate void Ido(double temp, double wind, int i);

    internal class Program
    {
        static void DisplayData(double temp, double wind, int i)
        {
            Console.WriteLine("Hőmérséklet: "+ temp + " °C");
            Console.WriteLine("Szélsebesség: "+ wind + " km/h");
            Console.WriteLine(WeatherDescription(i));
        }

        static string WeatherDescription(int i)
        {
            string result = "";
            if (i==0)
            {
                result = "Clear sky";
            }
            else if (i>=1 && i<=3)
            {
                result = "Mainly clear, partly cloudy, and overcast";
            }
            else if (i >= 45 && i <= 48)
            {
                result = "Fog and depositing rime fog";
            }
            else if (i >= 51 && i <= 55)
            {
                result = "Drizzle: Light, moderate, and dense intensity";
            }
            else if (i == 56 && i == 57)
            {
                result = "Freezing Drizzle: Light and dense intensity";
            }
            else if (i >= 61 && i <= 65)
            {
                result = "Rain: Slight, moderate and heavy intensity";
            }
            else if (i >= 66 && i <= 67)
            {
                result = "Freezing Rain: Light and heavy intensity";
            }
            else if (i >= 71 && i <= 75)
            {
                result = "Snow fall: Slight, moderate, and heavy intensity";
            }
            else if (i == 77)
            {
                result = "Snow grains";
            }
            else if (i >= 80 && i <= 82)
            {
                result = "Rain showers: Slight, moderate, and violent";
            }
            else if (i >= 85 && i <= 86)
            {
                result = "Snow showers slight and heavy";
            }
            else if (i == 95)
            {
                result = "Thunderstorm: Slight or moderate";
            }
            else if (i >= 96 && i <= 99)
            {
                result = "Thunderstorm with slight and heavy hail";
            }

            return result;
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Hol vagy?");
            string city = Console.ReadLine();
            Console.WriteLine("Időjárás itt: "+ city );
            display += DisplayData;
            GetWeather(GetCity(city));
            Console.ReadLine();
        }
        
        static string[] GetCity(string city)
        {
            string[] result = new string[2];
            using (WebClient web = new WebClient())
            {
                string url = "https://geocode.maps.co/search?q={" + city + "}";
                var json = web.DownloadString(url);
                List<City> info = JsonConvert.DeserializeObject<List<City>>(json);
                result[0] = info[0].lat;
                result[1] = info[0].lon;
            }
            return result;
        }

        public static Ido display;

        static void GetWeather(string[] coord)
        {
            using (WebClient web = new WebClient())
            {
                string url = $"https://api.open-meteo.com/v1/forecast?latitude={coord[0]}&longitude={coord[1]}&current_weather=true&hourly=temperature_2m,relativehumidity_2m,windspeed_10m";
                var json = web.DownloadString(url);
                Root info = JsonConvert.DeserializeObject<Root>(json);
                display(info.current_weather.temperature, info.current_weather.windspeed, info.current_weather.weathercode);
            }
        }
    }

    public class WeatherInfo
    {
        public class CurrentWeather
        {
            public double temperature { get; set; }
            public double windspeed { get; set; }
            public double winddirection { get; set; }
            public int weathercode { get; set; }
            public int is_day { get; set; }
            public string time { get; set; }
        }

        public class Hourly
        {
            public List<string> time { get; set; }
            public List<double> temperature_2m { get; set; }
            public List<int> relativehumidity_2m { get; set; }
            public List<double> windspeed_10m { get; set; }
        }

        public class HourlyUnits
        {
            public string time { get; set; }
            public string temperature_2m { get; set; }
            public string relativehumidity_2m { get; set; }
            public string windspeed_10m { get; set; }
        }

        public class Root
        {
            public double latitude { get; set; }
            public double longitude { get; set; }
            public double generationtime_ms { get; set; }
            public int utc_offset_seconds { get; set; }
            public string timezone { get; set; }
            public string timezone_abbreviation { get; set; }
            public double elevation { get; set; }
            public CurrentWeather current_weather { get; set; }
            public HourlyUnits hourly_units { get; set; }
            public Hourly hourly { get; set; }
        }
    }

    public class City
    {
        public int place_id { get; set; }
        public string licence { get; set; }
        public string powered_by { get; set; }
        public string osm_type { get; set; }
        public long osm_id { get; set; }
        public List<string> boundingbox { get; set; }
        public string lat { get; set; }
        public string lon { get; set; }
        public string display_name { get; set; }
        public string @class { get; set; }
        public string type { get; set; }
        public double importance { get; set; }
    }   
}
